// categories.js
// Shared logic for turning a CodeChef problem rating into a folder/category name.
// Loaded by both background.js (importScripts) and popup.js (<script> tag).

const DEFAULT_CATEGORIES = [
  { label: "0-1200 (Beginner)", min: 0, max: 1199 },
  { label: "1200-1399", min: 1200, max: 1399 },
  { label: "1400-1599", min: 1400, max: 1599 },
  { label: "1600-1799", min: 1600, max: 1799 },
  { label: "1800-1999", min: 1800, max: 1999 },
  { label: "2000-2199", min: 2000, max: 2199 },
  { label: "2200-2499", min: 2200, max: 2499 },
  { label: "2500-2999", min: 2500, max: 2999 },
  { label: "3000+", min: 3000, max: 999999 },
  { label: "Unrated", min: -1, max: -1 }
];

function categorizeRating(rating, categories) {
  const cats = categories && categories.length ? categories : DEFAULT_CATEGORIES;
  const r = Number(rating);
  if (!Number.isFinite(r) || r <= 0) {
    const unrated = cats.find(c => c.label.toLowerCase().includes("unrated"));
    return unrated ? unrated.label : "Unrated";
  }
  for (const c of cats) {
    if (r >= c.min && r <= c.max) return c.label;
  }
  return "Uncategorized";
}

function sanitizeFolderName(label) {
  return label.replace(/[\\/:*?"<>|]/g, "-").trim();
}

function extLangMap() {
  return {
    "C++14": "cpp", "C++17": "cpp", "C++20": "cpp", "C++": "cpp", "C++11": "cpp",
    "C": "c",
    "PYTH": "py", "PYTH 3": "py", "PYPY": "py", "PYPY3": "py", "Python": "py", "Python 3": "py",
    "JAVA": "java", "Java": "java",
    "JS": "js", "Node.js": "js", "JavaScript": "js",
    "GO": "go", "Go": "go",
    "RUST": "rs", "Rust": "rs",
    "KOTLIN": "kt", "Kotlin": "kt",
    "RUBY": "rb", "Ruby": "rb",
    "C#": "cs",
    "TEXT": "txt"
  };
}

function extForLanguage(lang) {
  if (!lang) return "txt";
  const map = extLangMap();
  if (map[lang]) return map[lang];
  const key = Object.keys(map).find(
    k => k.toLowerCase() === String(lang).toLowerCase()
  );
  return key ? map[key] : "txt";
}

// Export for service worker (importScripts) and for popup (plain script tag both
// just define globals since there's no module bundler involved).
if (typeof self !== "undefined") {
  self.DEFAULT_CATEGORIES = DEFAULT_CATEGORIES;
  self.categorizeRating = categorizeRating;
  self.sanitizeFolderName = sanitizeFolderName;
  self.extForLanguage = extForLanguage;
}
